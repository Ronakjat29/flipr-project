# Flipr Placement Task - Full Stack

Backend:
1. cd backend
2. cp .env.example .env and fill MONGO_URI
3. npm install
4. npm run dev
Frontend:
1. cd frontend
2. npm install
3. npm run dev
Notes:
- Backend serves uploads at /uploads. Frontend expects API at http://localhost:4000/api by default.
- Deploy backend to any Node hosting (Heroku/AWS) and frontend to Vercel/Netlify.
