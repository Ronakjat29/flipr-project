import React, {useEffect,useState} from 'react'
import api from '../api'
import ProjectCard from '../components/ProjectCard'
import ClientCard from '../components/ClientCard'
export default function Landing(){
  const [projects,setProjects] = useState([])
  const [clients,setClients] = useState([])
  const [contact,setContact] = useState({fullName:'',email:'',mobile:'',city:''})
  const [newsletterEmail,setNewsletterEmail] = useState('')
  useEffect(()=>{api.get('/projects').then(r=>setProjects(r.data)).catch(()=>{}) ; api.get('/clients').then(r=>setClients(r.data)).catch(()=>{})},[])
  function submitContact(e){
    e.preventDefault()
    api.post('/contacts',contact).then(()=>setContact({fullName:'',email:'',mobile:'',city:''}))
  }
  function subscribe(e){
    e.preventDefault()
    api.post('/subscribers',{email:newsletterEmail}).then(()=>setNewsletterEmail(''))
  }
  return <div>
    <header className="h-64 bg-gradient-to-r from-indigo-600 to-indigo-400 flex items-center justify-center text-white">
      <div className="text-center">
        <h1 className="text-4xl font-bold">Our Company</h1>
        <p className="mt-2">We build web experiences</p>
      </div>
    </header>
    <main className="p-8 space-y-12">
      <section>
        <h2 className="text-2xl mb-4">Our Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {projects.map(p=> <ProjectCard key={p._id} p={p}/>)}
        </div>
      </section>
      <section>
        <h2 className="text-2xl mb-4">Happy Clients</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {clients.map(c=> <ClientCard key={c._id} c={c}/>)}
        </div>
      </section>
      <section className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded shadow">
          <h3 className="text-xl mb-4">Contact Us</h3>
          <form onSubmit={submitContact} className="space-y-3">
            <input value={contact.fullName} onChange={e=>setContact({...contact,fullName:e.target.value})} required placeholder="Full Name" className="w-full p-2 border rounded"/>
            <input value={contact.email} onChange={e=>setContact({...contact,email:e.target.value})} required placeholder="Email" className="w-full p-2 border rounded"/>
            <input value={contact.mobile} onChange={e=>setContact({...contact,mobile:e.target.value})} required placeholder="Mobile" className="w-full p-2 border rounded"/>
            <input value={contact.city} onChange={e=>setContact({...contact,city:e.target.value})} required placeholder="City" className="w-full p-2 border rounded"/>
            <button className="px-4 py-2 bg-indigo-600 text-white rounded">Submit</button>
          </form>
        </div>
        <div className="bg-white p-6 rounded shadow flex flex-col justify-between">
          <div>
            <h3 className="text-xl mb-4">Newsletter</h3>
            <form onSubmit={subscribe} className="flex gap-2">
              <input value={newsletterEmail} onChange={e=>setNewsletterEmail(e.target.value)} required placeholder="Enter your email" className="flex-1 p-2 border rounded"/>
              <button className="px-4 py-2 bg-indigo-600 text-white rounded">Subscribe</button>
            </form>
          </div>
        </div>
      </section>
    </main>
  </div>
}
