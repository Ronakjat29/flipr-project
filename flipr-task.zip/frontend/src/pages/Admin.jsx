import React, {useEffect,useState} from 'react'
import api from '../api'
export default function Admin(){
  const [projects,setProjects]=useState([])
  const [clients,setClients]=useState([])
  const [contacts,setContacts]=useState([])
  const [subscribers,setSubscribers]=useState([])
  const [projForm,setProjForm]=useState({name:'',description:'',image:null})
  const [clientForm,setClientForm]=useState({name:'',designation:'',description:'',image:null})
  useEffect(()=>{refresh() },[])
  function refresh(){
    api.get('/projects').then(r=>setProjects(r.data))
    api.get('/clients').then(r=>setClients(r.data))
    api.get('/contacts').then(r=>setContacts(r.data))
    api.get('/subscribers').then(r=>setSubscribers(r.data))
  }
  function addProject(e){
    e.preventDefault()
    const fd = new FormData()
    fd.append('name',projForm.name)
    fd.append('description',projForm.description)
    fd.append('image',projForm.image)
    api.post('/projects',fd,{headers:{'Content-Type':'multipart/form-data'}}).then(()=>{setProjForm({name:'',description:'',image:null});refresh()})
  }
  function addClient(e){
    e.preventDefault()
    const fd = new FormData()
    fd.append('name',clientForm.name)
    fd.append('designation',clientForm.designation)
    fd.append('description',clientForm.description)
    fd.append('image',clientForm.image)
    api.post('/clients',fd,{headers:{'Content-Type':'multipart/form-data'}}).then(()=>{setClientForm({name:'',designation:'',description:'',image:null});refresh()})
  }
  function del(type,id){
    api.delete(`/`+type+`/`+id).then(()=>refresh())
  }
  return <div className="p-8">
    <h1 className="text-2xl mb-6">Admin Panel</h1>
    <div className="grid md:grid-cols-2 gap-6">
      <div className="bg-white p-4 rounded shadow">
        <h2 className="font-semibold">Add Project</h2>
        <form onSubmit={addProject} className="space-y-2 mt-3">
          <input value={projForm.name} onChange={e=>setProjForm({...projForm,name:e.target.value})} required placeholder="Name" className="w-full p-2 border rounded"/>
          <textarea value={projForm.description} onChange={e=>setProjForm({...projForm,description:e.target.value})} required placeholder="Description" className="w-full p-2 border rounded"/>
          <input type="file" onChange={e=>setProjForm({...projForm,image:e.target.files[0]})} required/>
          <button className="px-3 py-1 bg-indigo-600 text-white rounded">Add</button>
        </form>
      </div>
      <div className="bg-white p-4 rounded shadow">
        <h2 className="font-semibold">Add Client</h2>
        <form onSubmit={addClient} className="space-y-2 mt-3">
          <input value={clientForm.name} onChange={e=>setClientForm({...clientForm,name:e.target.value})} required placeholder="Name" className="w-full p-2 border rounded"/>
          <input value={clientForm.designation} onChange={e=>setClientForm({...clientForm,designation:e.target.value})} required placeholder="Designation" className="w-full p-2 border rounded"/>
          <textarea value={clientForm.description} onChange={e=>setClientForm({...clientForm,description:e.target.value})} required placeholder="Description" className="w-full p-2 border rounded"/>
          <input type="file" onChange={e=>setClientForm({...clientForm,image:e.target.files[0]})} required/>
          <button className="px-3 py-1 bg-indigo-600 text-white rounded">Add</button>
        </form>
      </div>
    </div>
    <div className="grid md:grid-cols-2 gap-6 mt-6">
      <div className="bg-white p-4 rounded shadow">
        <h2 className="font-semibold">Contacts</h2>
        <ul className="mt-3 space-y-2">
          {contacts.map(c=><li key={c._id} className="flex.justify-between items-start p-2 border rounded">
            <div>
              <div className="font-semibold">{c.fullName}</div>
              <div className="text-sm">{c.email} | {c.mobile} | {c.city}</div>
            </div>
            <button className="text-red-600" onClick={()=>del('contacts',c._id)}>Delete</button>
          </li>)}
        </ul>
      </div>
      <div className="bg-white p-4 rounded shadow">
        <h2 className="font-semibold">Subscribers</h2>
        <ul className="mt-3 space-y-2">
          {subscribers.map(s=><li key={s._id} className="flex justify-between items-center p-2 border rounded">
            <div>{s.email}</div>
            <button className="text-red-600" onClick={()=>del('subscribers',s._id)}>Delete</button>
          </li>)}
        </ul>
      </div>
    </div>
    <div className="mt-6 bg-white p-4 rounded shadow">
      <h2 className="font-semibold">Projects</h2>
      <div className="grid md:grid-cols-3 gap-4 mt-3">
        {projects.map(p=><div key={p._id} className="border p-2 rounded">
          <img src={p.image} className="w-full h-36 object-cover"/>
          <div className="mt-2 font-semibold">{p.name}</div>
          <div className="text-sm">{p.description}</div>
          <div className="mt-2 flex justify-between">
            <button className="text-red-600" onClick={()=>del('projects',p._id)}>Delete</button>
          </div>
        </div>)}
      </div>
      <h2 className="font-semibold mt-6">Clients</h2>
      <div className="grid md:grid-cols-3 gap-4 mt-3">
        {clients.map(c=><div key={c._id} className="border p-2 rounded flex flex-col items-center">
          <img src={c.image} className="w-20 h-20 object-cover rounded-full"/>
          <div className="mt-2 font-semibold">{c.name}</div>
          <div className="text-sm text-gray-500">{c.designation}</div>
          <div className="mt-2 text-sm">{c.description}</div>
          <button className="mt-2 text-red-600" onClick={()=>del('clients',c._id)}>Delete</button>
        </div>)}
      </div>
    </div>
  </div>
}
