import React from 'react'
import {createRoot} from 'react-dom/client'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom'
import './index.css'
import Landing from './pages/Landing'
import Admin from './pages/Admin'
function App(){
  return <BrowserRouter>
    <nav className="p-4 bg-gray-800 text-white flex justify-between">
      <Link to="/" className="font-bold">Company</Link>
      <Link to="/admin" className="bg-white text-gray-800 px-3 py-1 rounded">Admin</Link>
    </nav>
    <Routes>
      <Route path="/" element={<Landing/>}/>
      <Route path="/admin" element={<Admin/>}/>
    </Routes>
  </BrowserRouter>
}
createRoot(document.getElementById('root')).render(<App/>)
