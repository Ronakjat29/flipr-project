import React from 'react'
export default function ProjectCard({p}){
  return <div className="bg-white shadow rounded overflow-hidden">
    <img src={p.image} alt={p.name} className="w-full h-48 object-cover"/>
    <div className="p-4">
      <h3 className="font-semibold">{p.name}</h3>
      <p className="text-sm mt-2">{p.description}</p>
      <button className="mt-3 px-4 py-1 bg-blue-600 text-white rounded">Read More</button>
    </div>
  </div>
}
