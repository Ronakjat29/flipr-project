import React from 'react'
export default function ClientCard({c}){
  return <div className="bg-white p-4 rounded shadow flex gap-4 items-center">
    <img src={c.image} alt={c.name} className="w-20 h-20 object-cover rounded-full"/>
    <div>
      <h4 className="font-semibold">{c.name}</h4>
      <div className="text-xs text-gray-500">{c.designation}</div>
      <p className="text-sm mt-2">{c.description}</p>
    </div>
  </div>
}
