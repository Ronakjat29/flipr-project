const express = require('express')
const multer = require('multer')
const sharp = require('sharp')
const fs = require('fs')
const path = require('path')
const Project = require('../models/Project')
const router = express.Router()
const storage = multer.diskStorage({
  destination:function(req,file,cb){cb(null,'uploads/')},
  filename:function(req,file,cb){cb(null,Date.now()+'-'+file.originalname)}
})
const upload = multer({storage})
router.get('/',async(req,res)=>{const items=await Project.find().sort({_id:-1});res.json(items)})
router.post('/',upload.single('image'),async(req,res)=>{
  if(!req.file) return res.status(400).json({error:'no file'})
  const outPath = path.join('uploads','crop-'+req.file.filename)
  await sharp(req.file.path).resize(450,350,{fit:'cover'}).toFile(outPath)
  fs.unlinkSync(req.file.path)
  const proj = new Project({image:'/'+outPath,name:req.body.name,description:req.body.description})
  await proj.save()
  res.json(proj)
})
router.delete('/:id',async(req,res)=>{await Project.findByIdAndDelete(req.params.id);res.json({ok:true})})
module.exports = router
