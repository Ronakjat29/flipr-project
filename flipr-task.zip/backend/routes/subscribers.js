const express = require('express')
const Subscriber = require('../models/Subscriber')
const router = express.Router()
router.get('/',async(req,res)=>{const items=await Subscriber.find().sort({_id:-1});res.json(items)})
router.post('/',async(req,res)=>{const exists=await Subscriber.findOne({email:req.body.email});if(exists) return res.json(exists);const s=new Subscriber(req.body);await s.save();res.json(s)})
router.delete('/:id',async(req,res)=>{await Subscriber.findByIdAndDelete(req.params.id);res.json({ok:true})})
module.exports = router
