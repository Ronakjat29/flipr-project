const express = require('express')
const Contact = require('../models/Contact')
const router = express.Router()
router.get('/',async(req,res)=>{const items=await Contact.find().sort({_id:-1});res.json(items)})
router.post('/',async(req,res)=>{const c = new Contact(req.body);await c.save();res.json(c)})
router.delete('/:id',async(req,res)=>{await Contact.findByIdAndDelete(req.params.id);res.json({ok:true})})
module.exports = router
